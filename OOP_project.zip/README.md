# oop-s1-2022

When compile, please compile all three cpp files.

Introduction of this game:
Our project is a common card game -- Blackjack. 
The rules are the same as the standard game of blackjack, 
the computer is the dealer, initially both the player and the computer are given two cards, 
divided into open and dark cards, the player can know the dealer's open card to choose whether to add cards. 
There are three winning rules, the first is when all the cards add up to 21, 
the second is when one side has five cards but no more than 21, and the third is when one side stops to compare the numbers, 
and the bigger side wins. The ace can be positioned 1 or 11, at the player's discretion. 
And all J,Q and Ks count as 10 points.


This is lisence by 池深，張祥恩，喬和修。