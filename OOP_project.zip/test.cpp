#include <string>
#include <ctime>
#include <cstdlib>
#include <string>
#include <iostream>

using namespace std;

int main (){
    cout << "Hello World" << endl;
    return 0;
}